//= ../../../bower_components/jquery/dist/jquery.js
//= ../../../bower_components/popper.js/dist/umd/popper.js
//= ../../../bower_components/bootstrap/js/dist/util.js
//= ../../../bower_components/bootstrap/js/dist/tooltip.js
//= ../../../bower_components/bootstrap/js/dist/popover.js
//= ../../../bower_components/bootstrap/js/dist/collapse.js

//= custom/tooltips.js
//= custom/popover.js
